#!/usr/bin/env python
from distutils.core import setup



setup(
    name='redis-sort-queue',
    version='1.2.3',
    url='https://github.com/yordanglez/redis-sort-queue',
    description=(
        "ordered queue for redis"),
    long_description=open('README.rst').read(),
    author = "Yordano Gonzalez Fernandez",
    author_email = "yorda891216@gmail.com",
    keywords="Redis, Queue, Priority, Sort",
    platforms=['linux'],
    # packages=['redis_sort_queue'],
    install_requires=[
        'redis'],

)
